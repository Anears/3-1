// PL homework: hw2
// regexp_matcher.cc

#include "regexp_matcher.h"

#include <iostream>
#include <string>
#include <stack>

using namespace std;

int priority(char);
string PostfixRegExp(string);
bool ChkAlpha(char);
string ModifyRegExp(const char*);
void Regexp2Nfa(string, RegExpMatcher& rem);

bool BuildRegExpMatcher(const char* regexp, RegExpMatcher* regexp_matcher) {

	string modregexp = ModifyRegExp(regexp);
	string postregexp = PostfixRegExp(modregexp);
	
	//cout<<modregexp<<endl<<postregexp<<endl;

	regexp_matcher->nfa_size = 2;
	Regexp2Nfa(postregexp, *regexp_matcher);
	if(regexp_matcher->nfa_stack.size() != 1) return false;
	regexp_matcher->accept_states.push_back(regexp_matcher->nfa_stack.top().second);
	FSATableElement element = {1, regexp_matcher->nfa_stack.top().first, "#"};
	regexp_matcher->fsa_elements.push_back(element);
	
	/*for(auto x: regexp_matcher->accept_states) cout<<x<<endl;
	for(auto x:regexp_matcher->fsa_elements){
		cout<<x.state<<" "<<x.next_state<<" "<<x.str<<endl;
	}*/

	BuildFSA(regexp_matcher->fsa_elements, regexp_matcher->accept_states,  &(regexp_matcher->fsa));

  return true;
}

bool RunRegExpMatcher(const RegExpMatcher& regexp_matcher, const char* str) {
  return RunFSA(regexp_matcher.fsa, str);
}

bool ChkAlpha(char x) { return isalpha(x) || isdigit(x) || x == '_'; }

int priority(char ch){
	if(ch == '*') return 3;
	else if(ch == '.') return 2;
	else if(ch == '|') return 1;
	else return 0;
}

string PostfixRegExp(string regexp)
{
    string postregexp = "";
    stack<char> oper;
    for(int i=0; i<regexp.size(); ++i){
    	if(ChkAlpha(regexp[i])) postregexp += regexp[i];
    	else if(regexp[i] == '(') oper.push(regexp[i]);
    	else if(regexp[i] == ')'){
    		while(oper.top() != '('){
    			postregexp += oper.top();
    			oper.pop();
    		}
    		oper.pop();
    	}
    	else{
    		while(!oper.empty()){
    			if(priority(oper.top())>=priority(regexp[i])){
                    postregexp+=oper.top();
                    oper.pop();
                }
                else break;
    		}
    		oper.push(regexp[i]);
    	}
    }
    while(!oper.empty())
    {
        postregexp += oper.top();
        oper.pop();
    }
    return postregexp;
}

string ModifyRegExp(const char* regexp){
	string preregexp(regexp), modregexp = "";
	for(int i=0; i<preregexp.size(); ++i){
		if(preregexp[i] == '['){
			modregexp += '(';
			modregexp += preregexp[++i];
			while(preregexp[++i] != ']'){
				modregexp += '|';
				modregexp += preregexp[i];
			}
			modregexp += ')';
		}
		else if(preregexp[i] == '.') modregexp += "(a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|0|1|2|3|4|5|6|7|8|9|_)";
		else modregexp += preregexp[i];
	}
	
	preregexp = modregexp;
	modregexp = preregexp[0];
	for(int i=1; i<preregexp.size(); ++i){
        if(preregexp[i-1] != '(' && preregexp[i] != ')' && preregexp[i-1] != '|' && preregexp[i] != '|' && preregexp[i] != '*'){
            modregexp += '.';
        }
        modregexp += preregexp[i];    
	}
	return modregexp;
}

void Characters(char ch, RegExpMatcher& rem)
{
	string st = "";st += ch;
	FSATableElement element = {rem.nfa_size,rem.nfa_size+1,st};
	rem.fsa_elements.push_back(element);
	rem.nfa_stack.push(make_pair(element.state,element.next_state));
	rem.nfa_size += 2;
}

void OrOper(RegExpMatcher& rem)
{
	pair<int,int> sec = rem.nfa_stack.top();rem.nfa_stack.pop();
	pair<int,int> fir = rem.nfa_stack.top();rem.nfa_stack.pop();
	FSATableElement element1 = {rem.nfa_size, fir.first, "#"};
	FSATableElement element2 = {rem.nfa_size, sec.first, "#"};
	FSATableElement element3 = {fir.second, rem.nfa_size+1, "#"};
	FSATableElement element4 = {sec.second, rem.nfa_size+1, "#"};
	rem.fsa_elements.push_back(element1);
	rem.fsa_elements.push_back(element2);
	rem.fsa_elements.push_back(element3);
	rem.fsa_elements.push_back(element4);
    rem.nfa_stack.push(make_pair(rem.nfa_size,rem.nfa_size+1));
	rem.nfa_size += 2;
}

void AndOper(RegExpMatcher& rem)
{
	pair<int,int> sec = rem.nfa_stack.top();rem.nfa_stack.pop();
	pair<int,int> fir = rem.nfa_stack.top();rem.nfa_stack.pop();
	FSATableElement element = {fir.second, sec.first, "#"};
	rem.fsa_elements.push_back(element);
	rem.nfa_stack.push(make_pair(fir.first, sec.second));
}

void Repetition(RegExpMatcher& rem)
{
	pair<int,int> fir = rem.nfa_stack.top();rem.nfa_stack.pop();
	FSATableElement element1 = {fir.second, fir.first, "#"};
	FSATableElement element2 = {rem.nfa_size, fir.first, "#"};
	FSATableElement element3 = {fir.second, rem.nfa_size+1, "#"};
	FSATableElement element4 = {rem.nfa_size, rem.nfa_size+1, "#"};
	rem.fsa_elements.push_back(element1);
	rem.fsa_elements.push_back(element2);
	rem.fsa_elements.push_back(element3);
	rem.fsa_elements.push_back(element4);
	rem.nfa_stack.push(make_pair(rem.nfa_size,rem.nfa_size+1));
	rem.nfa_size += 2;
}

void Regexp2Nfa(string regexp, RegExpMatcher& rem)
{
	for(int i=0; i<regexp.size(); ++i){
		if(ChkAlpha(regexp[i])) Characters(regexp[i],rem);
		else if(regexp[i] == '*') Repetition(rem);
		else if(regexp[i] == '.') AndOper(rem);
		else if(regexp[i] == '|') OrOper(rem);
	}
}