// PL homework: hw2
// lr_parser.cc

#include <assert.h>

#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>

#include "lr_parser.h"

#define DISABLE_LOG false
#define LOG \
    if (DISABLE_LOG) {} else std::cerr

using namespace std;

bool BuildLRParser(const std::vector<LRTableElement>& elements,
                   const std::vector<LRRule>& rules,
                   LRParser* lr_parser) {
	for(auto element: elements)
		lr_parser->adj[element.state][element.symbol] = make_pair(element.action,element.next_state);

	for(auto rule: rules)
		lr_parser->rules[rule.id]=make_pair(rule.lhs_symbol,rule.num_rhs);

	return true;
}

bool RunLRParser(const LRParser& lr_parser, const std::string& str) {
	std::map<int,std::pair<int,int> > rules = lr_parser.rules;
	std::map<int,std::map<int,std::pair<LRAction,int> > > adj = lr_parser.adj;

	stack<int> parser_stack;
	string remain_str = str;
	parser_stack.push(0);
	while(remain_str != ""){
		int ch = remain_str[0];
		pair<LRAction, int> now = adj[parser_stack.top()][ch];
		if(now.first == SHIFT){
			parser_stack.push(ch);
			parser_stack.push(now.second);
			remain_str = remain_str.substr(1);
		}
		else if(now.first == REDUCE){
			pair<int,int> rule = rules[now.second];
			for(int i=0;i<rule.second*2;++i)
				parser_stack.pop();
			if (parser_stack.empty()) return false;
			pair<LRAction, int> sym = adj[parser_stack.top()][rule.first];
			if(sym.first == INVALID) return false;
			parser_stack.push(rule.first);
			parser_stack.push(sym.second);
		}
		else if(now.first == ACCEPT) return true;
		else if(now.first == INVALID) return false;

	}
  return false;
}