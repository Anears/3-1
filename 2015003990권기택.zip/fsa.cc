// PL homework: hw1
// fsa.cc

#include <iostream>
#include <algorithm>
#include <queue>

#include "fsa.h"

#define DISABLE_LOG true
#define LOG \
if (DISABLE_LOG) {} else std::cerr

  using namespace std;

bool ChkFSA(const FiniteStateAutomaton& fsa, int now_state, string str, set<int> vis) {
  //cout<<now_state+1<<" "<<str<<endl;
  if(str == "" && (fsa.accept.find(now_state) != fsa.accept.end())) {
    return true;
  }
  if(vis.find(now_state)!=vis.end()) return false;
  vis.insert(now_state);

  for(int i=0;i<fsa.adj[now_state].size();++i){
    pair<int,std::string> next = fsa.adj[now_state][i];
    if(next.second == "#" && ChkFSA(fsa, next.first, str, vis))
      return true;
    int pos;
    if((pos = str.find(next.second))==0 && ChkFSA(fsa, next.first, str.substr(next.second.size()), set<int>()))
      return true;
  }
  return false;
}

bool RunFSA(const FiniteStateAutomaton& fsa, const string& str) {

  /*queue<pair<int,string> >q;
  int start_idx = lower_bound(fsa.states.begin(),fsa.states.end(),start_state)-fsa.states.begin();
  q.push(make_pair(start_idx,str));
  while(!q.empty()){
      pair<int,string> now = q.front();q.pop();
      if(now.second=="") return true;

      //cout<<now.first<<" "<<now.second<<endl;
      for(auto next: fsa.adj[now.first]){
        //cout<<"** "<<next.first<<" "<<next.second;
        if(next.second == "#"){
          q.push(make_pair(next.first,now.second));
        }
        int pos;
        if((pos = now.second.find(next.second))==0){
          //cout<<"    "<<pos<<endl;
          q.push(make_pair(next.first,now.second.substr(next.second.size())));
        }
        //cout<<end
      }
      //string www;
      //getline(cin,www);
    }
  return false;*/

  int start_idx = lower_bound(fsa.states.begin(),fsa.states.end(),fsa.start_state)-fsa.states.begin();
  return ChkFSA(fsa, start_idx, str, set<int>());
}

bool BuildFSA(const std::vector<FSATableElement>& elements,
  const std::vector<int>& accept_states,
  FiniteStateAutomaton* fsa) {
  // Implement this function.
  LOG << "num_elements: " << elements.size()
  << ", accept_states: " << accept_states.size() << endl;

  set<int> stateSet;
  for(int i=0; i<elements.size(); ++i){
    stateSet.insert(elements[i].state);
    stateSet.insert(elements[i].next_state);
  }
  for(set<int>::iterator it=stateSet.begin();it!=stateSet.end();it++)
    fsa->states.push_back(*it);

  fsa->adj = vector<vector<pair<int,string> > >(fsa->states.size());
  for(int i=0;i<elements.size();++i){
    FSATableElement inf = elements[i];
    int u_idx,v_idx;
    u_idx = lower_bound(fsa->states.begin(),fsa->states.end(),inf.state)-fsa->states.begin();
    v_idx = lower_bound(fsa->states.begin(),fsa->states.end(),inf.next_state)-fsa->states.begin();
    fsa->adj[u_idx].push_back(make_pair(v_idx,inf.str));
  }

  for(int i=0;i<accept_states.size();++i){
    int state = accept_states[i];
    int idx = lower_bound(fsa->states.begin(),fsa->states.end(),state)-fsa->states.begin();
    fsa->accept.insert(idx);
  }
  fsa->start_state = 1;
  return true;
}

